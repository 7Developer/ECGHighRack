# EcoGaming - Community
# www.eco-gaming.com
# Mod: HIGH-LVL-RACK 
# Version: 1.0.6
# Discord: https://discord.gg/ps9fkTbAYv
# You can vote for new Skins and more on
# Discord in the #mod-talk Channel!

##########################################
Updates
# 1.0.6 - Fixed HighReckMeat Skin
# 1.0.5 - Fixed HighReckFreshFood
	- Changed Skin of HighReckRust
	- Reduced Mod Size
	- Optimized Materials
# 1.0.4 - Added LOD0
# 1.0.3 - Fine Adjusting Collider
# 1.0.2 - Fixed oversized Icons
# 1.0.1 - Racks can Stack now
	- New Standard icon
	- Removed Crafting Tab
# 1.0.0 added

#Known Bugs: Not Stackable at the moment

##########################################

You can craft all Racks in the Anvil, no Commands needed!
You can place the Racks Indoor & Outdoor!

Support us if you like the Mod & want to see more Updates: https://www.paypal.com/donate/?hosted_button_id=FNSNJWETY26V8
Thank you!

# Admin Commands:
/give HighReckRustItem
/give HighReckFreshFoodItem
/give HighReckMeatItem
/give HighReckVanillaItem